//
//  ImageFeedExtendTests2.swift
//  ImageFeedExtendTests2
//
//  Created by Nadin on 16.04.2025.
//
import XCTest

@testable import ImageFeedExtend

final class ImageFeedExtendTests2: XCTestCase {

        private let app = XCUIApplication() // переменная приложения
        
        override func setUpWithError() throws {
            continueAfterFailure = false // настройка выполнения тестов, которая прекратит выполнения тестов, если в тесте что-то пошло не так
            
            app.launch() // запускаем приложение перед каждым тестом
        }
        
    func testAuth() throws {
        // Тестируем сценарий авторизации

        // 1. Нажать кнопку авторизации
        let authButton = app.buttons["AuthButton"]
        XCTAssertTrue(authButton.waitForExistence(timeout: 30), "Кнопка авторизации 'AuthButton' не найдена")
        authButton.tap()

        // 2. Подождать, пока экран авторизации откроется и загрузится
        let webView = app.webViews["UnsplashWebView"]
        XCTAssertTrue(webView.waitForExistence(timeout: 500), "WebView 'UnsplashWebView' не загрузился")


        // 3. Ввести данные в форму авторизации
        let loginTextField = webView.descendants(matching: .textField).element
        XCTAssertTrue(loginTextField.waitForExistence(timeout: 30), "Поле логина не найдено")
        loginTextField.tap()
        loginTextField.typeText("minadin.m@gmail.com")

        let passwordTextField = webView.descendants(matching: .secureTextField).element
        XCTAssertTrue(passwordTextField.waitForExistence(timeout: 30), "Поле пароля не найдено")
        passwordTextField.tap()
        passwordTextField.typeText("1726252Kgt")

        // Скрываем клавиатуру при необходимости
        webView.swipeUp()

        // 4. Нажать кнопку логина
        let loginButton = webView.buttons["Login"]
        XCTAssertTrue(loginButton.waitForExistence(timeout: 30), "Кнопка логина не найдена")
        loginButton.tap()

        // 5. Подождать, пока загрузится лента
        let tablesQuery = app.tables
        let firstCell = tablesQuery.children(matching: .cell).element(boundBy: 0)
        XCTAssertTrue(firstCell.waitForExistence(timeout: 30), "Лента не загрузилась")
    }


            
            
        }
        
        func testFeed() throws {
            // тестируем сценарий ленты
        }
        
        func testProfile() throws {
            // тестируем сценарий профиля
        }
    
