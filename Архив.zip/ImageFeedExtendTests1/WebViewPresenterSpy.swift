//
//  WebViewPresenterSpy.swift
//  ImageFeedExtend
//
//  Created by Nadin on 13.04.2025.
//

import ImageFeedExtend
import Foundation

// Дубликат (шпион) для WebViewPresenter
final class WebViewPresenterSpy: WebViewPresenterProtocol {
    var viewDidLoadCalled: Bool = false
    var view: WebViewViewControllerProtocol?
    
    func viewDidLoad() {
        viewDidLoadCalled = true
    }
    
    func didUpdateProgressValue(_ newValue: Double) {
        // Ничего не делаем
    }
    
    func code(from url: URL) -> String? {
        return nil
    }
}
