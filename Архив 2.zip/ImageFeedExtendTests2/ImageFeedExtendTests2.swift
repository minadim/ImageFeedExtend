//
//  ImageFeedExtendTests2.swift
//  ImageFeedExtendTests2
//
//  Created by Nadin on 16.04.2025.
//
import XCTest

@testable import ImageFeedExtend

final class ImageFeedExtendTests2: XCTestCase {
    
    private let app = XCUIApplication() // переменная приложения
    
    override func setUpWithError() throws {
        continueAfterFailure = false // настройка выполнения тестов, которая прекратит выполнения тестов, если в тесте что-то пошло не так
        
        app.launch() // запускаем приложение перед каждым тестом
    }
    
    func testAuth() throws {

        // Тестируем сценарий авторизации
        
        // 1. Нажать кнопку авторизации
        let authButton = app.buttons["AuthButton"]
        print("🔍 AuthButton ok")
        print(app.debugDescription)
        XCTAssertTrue(authButton.waitForExistence(timeout: 30), "Кнопка авторизации 'AuthButton' не найдена")
        authButton.tap()
        
        // 2. Подождать, пока экран авторизации откроется и загрузится
        let webView = app.webViews.element(boundBy: 0)
        print(app.debugDescription)
        print("🔍 Trying to find UnsplashWebView 🖥️")
        XCTAssertTrue(webView.waitForExistence(timeout: 30), "'UnsplashWebView' не загрузился")
        
        // 3. Ввести данные в форму авторизации
        let loginTextField = webView.descendants(matching: .textField).element
        XCTAssertTrue(loginTextField.waitForExistence(timeout: 30), "Поле логина не найдено")
        loginTextField.tap()
        loginTextField.typeText("minadin.m@gmail.com")
        webView.swipeUp()
        sleep(5)
        // Ввод пароля
        let passwordTextField = webView.descendants(matching: .secureTextField).element
        XCTAssertTrue(passwordTextField.waitForExistence(timeout: 30), "Поле пароля не найдено")
        XCTAssertTrue(passwordTextField.isHittable, "Поле пароля не доступно для нажатия")

        let coordinate = passwordTextField.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5))
        passwordTextField.tap()
        sleep(5)
        let keyboard = app.keyboards.firstMatch
        XCTAssertTrue(keyboard.waitForExistence(timeout: 10), "Клавиатура не появилась")
        print(app.debugDescription)
        webView.swipeUp()
        passwordTextField.typeText("1726252Kgt")
        webView.swipeUp()
        print(app.debugDescription)
        
        // 4. Нажать кнопку логина
        let loginButton = webView.buttons["Login"]
        XCTAssertTrue(loginButton.waitForExistence(timeout: 30), "Кнопка логина не найдена")
        loginButton.tap()
        // Проверяем, что экран после "Login" действительно загрузился
        sleep(15) // или используйте XCTestExpectation для более точного ожидания
        
        // 5. Подождать, пока загрузится лента
        let tablesQuery = app.tables
        
        // Выводим иерархию для диагностики
        print(app.debugDescription)
        
        // Проверяем, что хотя бы одна таблица существует
        XCTAssertTrue(tablesQuery.element.waitForExistence(timeout: 50), "Таблица не найдена на экране")
        
        // Прокручиваем таблицу (если она присутствует)
        let tableElement = tablesQuery.element
        tableElement.swipeUp()
        
        // Ищем ячейку по заданному identifier, который должен быть установлен в приложении
        let cell = app.tables.cells["ImagesListCell"]
        XCTAssertTrue(cell.waitForExistence(timeout: 120), "Лента не загрузилась")
    }
    
    func testFeed() throws {
        // 1) Ждём появления таблицы
        let table = app.tables["ImagesListTable"]
        XCTAssertTrue(table.waitForExistence(timeout: 10), "Таблица не появилась")
        sleep(15)
        // 2) Берём вторую ячейку
        let secondCell = table.cells.element(boundBy: 1)
        XCTAssertTrue(secondCell.waitForExistence(timeout: 5), "Вторая ячейка не найдена")
        sleep(15)

     //    4) Находим кнопку «off» внутри второй ячейки и тапаем
        let likeButton = secondCell.buttons["Like Button"]

        // Проверяем OFF
        XCTAssertEqual(likeButton.value as? String, "Off")
        likeButton.tap()
        sleep(15)
        // Проверяем ON
        XCTAssertEqual(likeButton.value as? String, "On")


        
        // 6) Тапаем «on»
        likeButton.tap()
        sleep(15)

        // 4. Открываем полноэкранное изображение в этой же ячейке
        let cellImage = secondCell.images.element(boundBy: 0)
        XCTAssertTrue(cellImage.waitForExistence(timeout: 5), "Изображение не найдено")
        cellImage.tap()    // здесь tap по image внутри secondCell

        // 5. Ждём, что view с UIScrollView покажет картинку
        let fullImage = app.scrollViews.images.firstMatch
        XCTAssertTrue(fullImage.waitForExistence(timeout: 5), "Полноэкранного изображения нет")

        // 6. Зум и анзум
        fullImage.pinch(withScale: 3.0, velocity: 1.0)
        fullImage.pinch(withScale: 0.5, velocity: -1.0)

        // 7. Назад к ленте
        let backButton = app.buttons["nav back button white"]
        XCTAssertTrue(backButton.waitForExistence(timeout: 5), "Кнопка «Назад» не найдена")
        backButton.tap()
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
        func testFeed() throws {
            // тестируем сценарий ленты
        }
        
        func testProfile() throws {
            // тестируем сценарий профиля
        }
    

