//
//  WebViewViewControllerSpy.swift
//  ImageFeedExtend
//
//  Created by Nadin on 13.04.2025.
//
import ImageFeedExtend
import Foundation
    
    // Дублёр WebViewViewController
final class WebViewViewControllerSpy: WebViewViewControllerProtocol {
   
    func load(request: URLRequest) {
        isLoadRequestCalled = true
    }
    
        var isLoadRequestCalled = false
        
        // Заглушки для других методов протокола, если есть
        func setProgressValue(_ newValue: Float) {}
        func setProgressHidden(_ isHidden: Bool) {}
        
        var presenter: WebViewPresenterProtocol?
    }
