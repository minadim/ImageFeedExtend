//
//  WebViewPresenter.swift
//  ImageFeedExtend
//
//  Created by Nadin on 11.04.2025.
//

import UIKit

public protocol WebViewPresenterProtocol {
    var view: WebViewViewControllerProtocol? { get set }
    func viewDidLoad() // ✅ Добавлено
    func didUpdateProgressValue(_ newValue: Double) // ✅ Добавили метод для получения прогресса от WebView
    // ✅ Добавлено по заданию: метод для извлечения кода из URL
       func code(from url: URL) -> String?
}

final class WebViewPresenter: WebViewPresenterProtocol {
    weak var view: WebViewViewControllerProtocol?
    
    // ⬇️ Заменили прямое использование конфигурации на хелпер
       var authHelper: AuthHelperProtocol

       // ⬇️ Внедрение зависимости через инициализатор
       init(authHelper: AuthHelperProtocol) {
           self.authHelper = authHelper
       }
    
    // ✅ Добавлено
       func viewDidLoad() {
           // ⬇️ Используем authHelper для получения запроса
                  guard let request = authHelper.authRequest() else { return }

         //  urlComponents.queryItems = [
           //    URLQueryItem(name: "client_id", value: Constants.accessKey),
          //     URLQueryItem(name: "redirect_uri", value: Constants.redirectURI),
          //     URLQueryItem(name: "response_type", value: "code"),
         //      URLQueryItem(name: "scope", value: Constants.accessScope)
          // ]

       //    guard let url = urlComponents.url else {
       //        return
      //     }

      //     let request = URLRequest(url: url)
           didUpdateProgressValue(0) // ✅ Инициализируем прогресс на старте
           view?.load(request: request)
       }

    func didUpdateProgressValue(_ newValue: Double) { // ✅ Реализация логики отображения прогресса
          let newProgressValue = Float(newValue)
          view?.setProgressValue(newProgressValue)
          let shouldHideProgress = shouldHideProgress(for: newProgressValue)
          view?.setProgressHidden(shouldHideProgress)
      }

      func shouldHideProgress(for value: Float) -> Bool { // ✅ Метод определения скрытия progressView
          abs(value - 1.0) <= 0.0001
      }
    
    // ✅ Реализация нового метода, перенесённого из ViewController
      func code(from url: URL) -> String? {
          // ⬇️ Делегируем логику парсинга кода хелперу
                authHelper.code(from: url)
          }
      }
    

       // ✅ Добавлено
   //    private enum WebViewConstants {
     //      static let unsplashAuthorizeURLString = "https://unsplash.com/oauth/authorize"
 //      }
   
    
    
    
    
    
    
    
    
    
    
    
    

